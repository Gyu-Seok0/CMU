# DO NOT import any additional 3rd party external libraries as they will not
# be available to AutoLab and are not needed (or allowed)

import numpy as np
import os
import sys

sys.path.append('mytorch')
from loss import *
from activation import *
from linear import *
from conv import *


class CNN_SimpleScanningMLP():
    def __init__(self):
        ## Your code goes here -->
        # self.conv1 = ???
        # self.conv2 = ???
        # self.conv3 = ???
        # ...
        # <---------------------
        self.conv1 = Conv1d(24,8,8,4) #in_channels, out_channels, kernel_size, stride,
        self.conv2 = Conv1d(8,16,1,1) 
        self.conv3 = Conv1d(16,4,1,1)
        self.layers = [self.conv1, ReLU(), self.conv2, ReLU(), self.conv3, Flatten()]

    def init_weights(self, weights):
        # Load the weights for your CNN from the MLP Weights given
        # w1, w2, w3 contain the weights for the three layers of the MLP
        # Load them appropriately into the CNN

        w1,w2,w3 = weights
        w1_t = w1.T
        result = []
        for out_c in range(len(w1_t)):
            result.append(np.stack(np.split(w1_t[out_c], 8), axis = 1))
        stack_result = np.stack(result, axis = 0)

        w1_r = stack_result

        w2_t = w2.T
        w2_r = np.expand_dims(w2_t,2)

        w3_t = w3.T
        w3_r = np.expand_dims(w3_t,2)
 
        self.conv1.conv1d_stride1.W = w1_r
        self.conv2.conv1d_stride1.W = w2_r
        self.conv3.conv1d_stride1.W = w3_r

    def forward(self, A):
        """
        Do not modify this method

        Argument:
            A (np.array): (batch size, in channel, in width)
        Return:
            Z (np.array): (batch size, out channel , out width)
        """

        Z = A
        for layer in self.layers:
            Z = layer.forward(Z)
        return Z

    def backward(self, dLdZ):
        """
        Do not modify this method

        Argument:
            dLdZ (np.array): (batch size, out channel, out width)
        Return:
            dLdA (np.array): (batch size, in channel, in width)
        """

        for layer in self.layers[::-1]:
            dLdA = layer.backward(dLdA)
        return dLdA


class CNN_DistributedScanningMLP():
    def __init__(self):
        ## Your code goes here -->
        # self.conv1 = ???
        # self.conv2 = ???
        # self.conv3 = ???
        # ...
        # <---------------------
        self.conv1 = Conv1d(24,2,2,2) #in_channels, out_channels, kernel_size, stride,
        self.conv2 = Conv1d(2,8,2,2) 
        self.conv3 = Conv1d(8,4,2,1)
        self.layers = [self.conv1, ReLU(), self.conv2, ReLU(), self.conv3, Flatten()]

    def __call__(self, A):
        # Do not modify this method
        return self.forward(A)

    def init_weights(self, weights):
        # Load the weights for your CNN from the MLP Weights given
        # w1, w2, w3 contain the weights for the three layers of the MLP
        # Load them appropriately into the CNN

        w1, w2, w3 = weights
        # print("w1",w1.shape)
        # print("w2",w2.shape)
        # print("w3",w3.shape)
        # print("w1",w1)
        # print("w2",w2)
        # print("w3",w3)
        
        
        # w1_t = w1.T
        # result = []
        # for out_c in range(len(w1_t)):
        #     result.append(np.stack(np.split(w1_t[out_c], 8), axis = 1))
        # stack_result = np.stack(result, axis = 0)
        # w1_tt = stack_result[:2,:24,:2]
        # w1_ttt = np.concatenate([w1_tt for _ in range(4)], axis = 2)
        # w1_tttt = np.concatenate([w1_ttt for _ in range(4)], axis = 0)
        # w1_r = w1_tttt 

        # w1_c = np.concatenate([w1[:48,:2] for _ in range(4)], axis = 1)
        # w1_cr = np.concatenate([w1_c for _ in range(4)], axis = 0)
        # w1_t = w1_cr.T
        # result = []
        # for out_c in range(len(w1_t)):
        #     result.append(np.stack(np.split(w1_t[out_c], 8), axis = 1))
        # stack_result = np.stack(result, axis = 0)

        w1_t = w1.T
        result = []
        for out_c in range(len(w1_t)):
            result.append(np.stack(np.split(w1_t[out_c], 8), axis = 1))
        stack_result = np.stack(result, axis = 0)
        w1_r = stack_result[:2,:24,:2]
        #print("w1_r",w1_r.shape)
 

        #w2_t = w2.T
        #w2_c = np.concatenate([w2_t[:8, :2,],w2_t[:8, :2,],w2_t[:8, :2,],w2_t[:8, :2,]], axis = 1)
        #w2_cc = np.concatenate([w2_c,w2_c], axis = 0)
        #w2_r = np.expand_dims(w2_cc, 2)
        #np_n = np.array(w2[:4,:8])
        #np_n_c = np.concatenate([np_n,np_n], axis = 1)
        #np_n_cr = np.concatenate([np_n_c, np_n_c], axis = 0)
        #w2_r = np.expand_dims(np_n_cr.T, axis = 2)
        w2_t = w2.T
        w2_r = np.stack(np.split(w2_t[:8,:4], 2, axis = 1), axis = 2)
        #w2_r = w2_t[:8,:4].reshape(8,2,2)
        
        #print("w2_r",w2_r.shape)
        #print(w2_r)


        w3_t = w3.T
        #w3_c = np.concatenate([w3_t[:4,:8], w3_t[:4,:8]], axis = 1)
        #w3_r = np.expand_dims(w3_t,2)
        w3_r = np.stack(np.split(w3_t, 2, axis = 1), axis = 2)
        #print("w3_r", w3_r.shape)
 
        self.conv1.conv1d_stride1.W = w1_r
        self.conv2.conv1d_stride1.W = w2_r
        self.conv3.conv1d_stride1.W = w3_r

    def forward(self, A):
        """
        Do not modify this method

        Argument:
            A (np.array): (batch size, in channel, in width)
        Return:
            Z (np.array): (batch size, out channel , out width)
        """

        Z = A
        for layer in self.layers:
            #print("input",Z.shape)
            #print("layer",layer.conv1d_stride1.W.shape)
            Z = layer.forward(Z)
            #print("output",Z.shape)
        return Z

    def backward(self, dLdZ):
        """
        Do not modify this method

        Argument:
            dLdZ (np.array): (batch size, out channel, out width)
        Return:
            dLdA (np.array): (batch size, in channel, in width)
        """
        dLdA = dLdZ
        for layer in self.layers[::-1]:
            dLdA = layer.backward(dLdA)
        return dLdA
