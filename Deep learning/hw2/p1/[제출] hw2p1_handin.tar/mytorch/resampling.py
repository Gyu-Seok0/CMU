import numpy as np

class Upsample1d():

    def __init__(self, upsampling_factor):
        self.upsampling_factor = upsampling_factor

    def forward(self, A):

        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width)
        Return:
            Z (np.array): (batch_size, in_channels, output_width)
        """
        batchs = []
        for batch_idx in range(len(A)):
            batch = A[batch_idx]
            channels = []
            for channel in batch:
                transform = []
                for idx,num in enumerate(channel):
                    transform += [num]
                    if idx < len(channel)-1:
                        transform += [0] * (self.upsampling_factor-1)
                channels.append(transform)
            batchs.append(channels)

                
        Z = np.array(batchs) # TODO
        return Z

    def backward(self, dLdZ):

        """
        Argument:
            dLdZ (np.array): (batch_size, in_channels, output_width)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width)
        """

        batchs = []
        for batch_idx in range(len(dLdZ)):
            batch = dLdZ[batch_idx]
            channels = []
            for channel in batch:
                transform = []
                for i in range(0, len(channel), self.upsampling_factor):
                    transform += [channel[i]]
                channels.append(transform)
            batchs.append(channels)

        dLdA = np.array(batchs) #TODO

        return dLdA

class Downsample1d():

    def __init__(self, downsampling_factor):
        self.downsampling_factor = downsampling_factor
        self.A = None

    def forward(self, A):

        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width)
        Return:
            Z (np.array): (batch_size, in_channels, output_width)
        """
        self.A = A

        batchs = []
        for batch_idx in range(len(A)):
            batch = A[batch_idx]
            channels = []
            for channel in batch:
                transform = []
                for i in range(0, len(channel), self.downsampling_factor):
                    transform += [channel[i]]
                channels.append(transform)
            batchs.append(channels)

        Z = np.array(batchs) # TODO

        return Z

    def backward(self, dLdZ):

        """
        Argument:
            dLdZ (np.array): (batch_size, in_channels, output_width)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width)
        """
        batchs = []
        for batch_idx in range(len(dLdZ)):
            batch = dLdZ[batch_idx]
            channels = []

            for channel_idx in range(len(batch)):
                channel = batch[channel_idx]
                transform = []

                for idx,num in enumerate(channel):
                    transform += [num]
                    if idx < len(channel)-1:
                        transform += [0] * (self.downsampling_factor-1)
                    
                while len(self.A[batch_idx][channel_idx]) > len(transform):
                    transform += [0]

                channels.append(transform)
            batchs.append(channels)

                        
        dLdA = np.array(batchs)  #TODO

        return dLdA

class Upsample2d():

    def __init__(self, upsampling_factor):
        self.upsampling_factor = upsampling_factor

    def forward(self, A):

        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, in_channels, output_width, output_height)
        """
        def add_pad(row, upsampling_factor):
            trans_row = []
            for i in range(len(row)):
                trans_row.append(row[i])
                if i < len(row)-1:
                    trans_row += [0] * (upsampling_factor - 1)
            return trans_row
                
                
        new_A = []
        for batch_idx in range(len(A)):
            batch = A[batch_idx]
            new_batch = []
            for c_idx in range(len(batch)):
                channel = batch[c_idx]
                new_channels = []
                for row_idx in range(len(channel)):
                    #print(channel[row_idx])
                    row = channel[row_idx]
                    pad_row = add_pad(row, self.upsampling_factor)
                    new_channels.append(pad_row)
                    if row_idx + 1 < len(channel):
                        for _ in range(self.upsampling_factor - 1):
                            new_channels.append([0] * len(pad_row))
                new_batch.append(new_channels)
            new_A.append(new_batch)

        Z = np.array(new_A) # TODO

        return Z

    def backward(self, dLdZ):

        """
        Argument:
            dLdZ (np.array): (batch_size, in_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        def remove_pad(row, upsampling_factor):
            trans_row = []
            for i in range(0,len(row),upsampling_factor):
                trans_row.append(row[i])
            return trans_row

        new_A = []
        for batch_idx in range(len(dLdZ)):
            batch = dLdZ[batch_idx]
            new_batch = []
            for c_idx in range(len(batch)):
                channel = batch[c_idx]
                new_channels = []
                for row_idx in range(0,len(channel),self.upsampling_factor):
                    #print(channel[row_idx])
                    row = channel[row_idx]
                    pad_row = remove_pad(row,self.upsampling_factor)
                    new_channels.append(pad_row)
                new_batch.append(new_channels)
            new_A.append(new_batch)

        dLdA = np.array(new_A) #TODO

        return dLdA

class Downsample2d():

    def __init__(self, downsampling_factor):
        self.downsampling_factor = downsampling_factor

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, in_channels, output_width, output_height)
        """
        self.A = A
        def remove_pad(row, downsampling_factor):
            trans_row = []
            for i in range(0,len(row),downsampling_factor):
                trans_row.append(row[i])
            return trans_row

        new_A = []
        for batch_idx in range(len(A)):
            batch = A[batch_idx]
            new_batch = []
            for c_idx in range(len(batch)):
                channel = batch[c_idx]
                new_channels = []
                for row_idx in range(0, len(channel), self.downsampling_factor):
                    row = channel[row_idx]
                    pad_row = remove_pad(row , self.downsampling_factor)
                    new_channels.append(pad_row)
                new_batch.append(new_channels)
            new_A.append(new_batch)

        Z = np.array(new_A) #TODO

        return Z

    def backward(self, dLdZ):

        """
        Argument:
            dLdZ (np.array): (batch_size, in_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        def add_pad(row, downsampling_factor):
            trans_row = []
            for i in range(len(row)):
                trans_row.append(row[i])
                if i < len(row)-1:
                    trans_row += [0] * (downsampling_factor - 1)
            return trans_row
                
                
        new_A = []
        for batch_idx in range(len(dLdZ)):
            batch = dLdZ[batch_idx]
            new_batch = []
            for c_idx in range(len(batch)):
                channel = batch[c_idx]
                new_channels = []
                for row_idx in range(len(channel)):
                    row = channel[row_idx]
                    pad_row = add_pad(row, self.downsampling_factor)
                    while len(self.A[batch_idx][c_idx][row_idx]) > len(pad_row):
                        pad_row.append(0)

                    new_channels.append(pad_row)
                    if row_idx + 1 < len(channel):
                        for _ in range(self.downsampling_factor - 1):
                            new_channels.append([0] * len(pad_row))
                while len(self.A[batch_idx][c_idx]) > len(new_channels):
                    new_channels.append([0] * len(pad_row))

                new_batch.append(new_channels)
            new_A.append(new_batch)
        
        dLdA = np.array(new_A)   #TODO

        return dLdA