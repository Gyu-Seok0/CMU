import numpy as np
from resampling import *

class MaxPool2d_stride1():

    def __init__(self, kernel):
        self.kernel = kernel
        self.max_pool_idx = None

    def forward(self, A):
        self.A = A
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """

        def max_pool(image, kernel):
            width, height = image.shape
            output = np.zeros((width - kernel + 1, height - kernel + 1))
            output_idx = []
            for w_idx in range(0,width - kernel +1, 1):
                for h_idx in range(0, height - kernel +1, 1):
                    target = image[w_idx:w_idx+kernel, h_idx:h_idx+kernel]
                    max_idx = np.unravel_index(target.argmax(), target.shape)
                    max_value = target[max_idx]

                    output[w_idx, h_idx] = max_value
                    output_idx.append((max_idx[0] + w_idx, max_idx[1] + h_idx))
            return output, output_idx

        max_pool_idx = [[] for _ in range(len(A))]
        max_pool_result = []
        for b_idx in range(len(A)):
            batch = A[b_idx]
            new_batch = []
            for c_idx in range(len(batch)):
                image = batch[c_idx]
                output, output_idx = max_pool(image, self.kernel)

                #save
                max_pool_idx[b_idx].append(output_idx) # maxpooling index
                new_batch.append(output)
            max_pool_result.append(np.stack(new_batch, axis = 0))
        ans = np.stack(max_pool_result, axis = 0)
        self.max_pool_idx = max_pool_idx 

        return ans
    
    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        dLdA = np.zeros(self.A.shape)
        for b_idx in range(len(dLdZ)):
            batch = dLdZ[b_idx]
            for c_idx in range(len(batch)):
                c_batch = batch[c_idx]
                max_c_idx = self.max_pool_idx[b_idx][c_idx]
                for idx, value in enumerate(c_batch.reshape(-1,)):
                    row,col = max_c_idx[idx]
                    dLdA[b_idx][c_idx][row][col] += value
        
        return dLdA

class MeanPool2d_stride1():

    def __init__(self, kernel):
        self.kernel = kernel

        self.dLdA = None

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        self.A = A
        def mean_pool(image, kernel):
            width, height = image.shape
            output = np.zeros((width - kernel + 1, height - kernel + 1))
            for w_idx in range(0,width - kernel +1, 1):
                for h_idx in range(0, height - kernel +1, 1):
                    target = image[w_idx:w_idx+kernel, h_idx:h_idx+kernel]
                    mean_value = np.mean(target)            
                    output[w_idx, h_idx] = mean_value
            return output


        mean_pool_result = []
        for b_idx in range(len(A)):
            batch = A[b_idx]
            new_batch = []
            for c_idx in range(len(batch)):
                image = batch[c_idx]
                output = mean_pool(image, self.kernel)
                
                #save
                new_batch.append(output)
            mean_pool_result.append(np.stack(new_batch, axis = 0))
        ans = np.stack(mean_pool_result, axis = 0)

        return ans


    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        def mean_backward(c_batch, target, kernel):
            width,height = c_batch.shape
            for w_idx in range(0, width - kernel + 1, 1):
                for h_idx in range(0, height - kernel +1, 1):
                    value = target[w_idx,h_idx] / (kernel**2)
                    c_batch[w_idx:w_idx+kernel, h_idx:h_idx+kernel] += value
            return c_batch
            

            
        dLdA = np.zeros(self.A.shape)
        for b_idx in range(len(dLdA)):
            batch = dLdA[b_idx]
            batch_output = []
            for c_idx in range(len(batch)):
                c_batch = batch[c_idx]
                target = dLdZ[b_idx][c_idx]
                dLdA[b_idx][c_idx] = mean_backward(c_batch, target, self.kernel)

        return dLdA

class MaxPool2d():

    def __init__(self, kernel, stride):
        self.kernel = kernel
        self.stride = stride
        
        #Create an instance of MaxPool2d_stride1
        self.maxpool2d_stride1 = MaxPool2d_stride1(kernel) #TODO
        self.downsample2d = Downsample2d(stride) #TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        max_A = self.maxpool2d_stride1.forward(A)
        down_A = self.downsample2d.forward(max_A) 
        return down_A
        
    
    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        down_dLdZ = self.downsample2d.backward(dLdZ)
        dLdA = self.maxpool2d_stride1.backward(down_dLdZ)
        return dLdA

class MeanPool2d():

    def __init__(self, kernel, stride):
        self.kernel = kernel
        self.stride = stride

        #Create an instance of MaxPool2d_stride1
        self.meanpool2d_stride1 = MeanPool2d_stride1(kernel) #TODO
        self.downsample2d = Downsample2d(stride) #TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        mean_A = self.meanpool2d_stride1.forward(A)
        down_A = self.downsample2d.forward(mean_A)
        return down_A

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        dLdA = self.downsample2d.backward(dLdZ)
        dLdA = self.meanpool2d_stride1.backward(dLdA)

        return dLdA
