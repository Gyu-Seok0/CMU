# Do not import any additional 3rd party external libraries as they will not
# be available to AutoLab and are not needed (or allowed)

from audioop import mul
import numpy as np
from resampling import *

class Conv1d_stride1():
    def __init__(self, in_channels, out_channels, kernel_size,
                 weight_init_fn=None, bias_init_fn=None):
        # Do not modify this method
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size

        if weight_init_fn is None:
            self.W = np.random.normal(0, 1.0, (out_channels, in_channels, kernel_size))

        else:
            self.W = weight_init_fn(out_channels, in_channels, kernel_size)

        if bias_init_fn is None:
            self.b = np.zeros(out_channels)
        else:
            self.b = bias_init_fn(out_channels)

        self.dLdW = np.zeros(self.W.shape)
        self.dLdb = np.zeros(self.b.shape)

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_size)
        Return:
            Z (np.array): (batch_size, out_channels, output_size)
        """
        self.A = A

        def convolve(batch, kernel, bias):
            kernel_size = kernel.shape[1]
            conv_result = []
            
            for start in range(batch.shape[1] - kernel_size + 1):
                target = batch[:, start: start + kernel_size]
                mul_target = np.sum(target * kernel)
                mul_target += bias
                conv_result.append(mul_target)
                
            return conv_result

        
        new_batch = []
        for batch_idx in range(len(A)):
            batch = A[batch_idx]
            outputs = []
            for W_idx in range(len(self.W)):
                kernel = self.W[W_idx]
                bias = self.b[W_idx] 
                output = convolve(batch, kernel, bias)
                outputs.append(output)
            new_batch.append(outputs)     

        Z = np.array(new_batch) # TODO
        
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_size)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_size)
        """

        
        
        def conv_1d_backward(image, kernel): # image = (dim,) kernel = (input_channel x kernel_size)
            kerenl_size = kernel.shape[1]
            ans = None
            for start in range(0, image.shape[0] - kernel_size + 1, 1):
                conv = np.dot(kernel, image[start:start + kernel_size].reshape(-1,1))
                if ans is None:
                    ans = conv
                else:
                    ans = np.concatenate([ans,conv], axis = 1) # (input_channel x convolution width)
            return ans
            


        def make_dLdW(batch, kernel):
            kernel_size = kernel.shape[0]
            ans = None
            for start in range(0, batch.shape[1] - kernel_size + 1, 1):
                conv = np.dot(batch[:,start:start+kernel_size], kernel.reshape(-1,1))
                if ans is None:
                    ans = conv
                else:
                    ans = np.concatenate([ans, conv], axis = 1)
            return ans

        outputs = None
        for batch_idx in range(len(self.A)):
            batch = self.A[batch_idx]
            kernels = dLdZ[batch_idx]
            output = []
            for k_idx in range(len(kernels)):
                kernel = kernels[k_idx]
                conv_output = make_dLdW(batch,kernel) # C0 x K
                output.append(conv_output)
            output = np.array(output) # C1 x C0 x K
            if outputs is None:
                outputs = output
            else:
                outputs = np.add(outputs, output)


        self.dLdW = outputs # TODO dLdZ * self.A #여기부터 다시.    
        self.dLdb = np.sum(dLdZ, axis=(0,2)) # TODO -> (C1, )


        kernel_size = self.W.shape[2]
        output_kernel = self.W.shape[0]
        outputs = []
        for batch_idx in range(len(dLdZ)):
            batch = dLdZ[batch_idx]
            batch = np.pad(batch, ((0,0), (kernel_size-1, kernel_size-1)), "constant", constant_values = 0)
            #print(batch.shape)
            output = None
            for k_idx in range(output_kernel):
                image = batch[k_idx,:]
                kernel = self.W[k_idx,:,:]
                kernel = np.flip(kernel, 1)

                ans = conv_1d_backward(image, kernel)
                if output is None:
                    output = ans
                else:
                    output = np.add(output, ans) # (input_channel x convolution width)
            outputs.append(output)

        dLdA = np.array(outputs) # TODO

        return dLdA

class Conv1d():
    def __init__(self, in_channels, out_channels, kernel_size, stride,
                weight_init_fn=None, bias_init_fn=None):
        # Do not modify the variable names
    
        self.stride = stride

        # Initialize Conv1d() and Downsample1d() isntance
        self.conv1d_stride1 = Conv1d_stride1(in_channels, out_channels, kernel_size,
                 weight_init_fn=weight_init_fn, bias_init_fn=bias_init_fn) # TODO
        
        self.downsample1d = Downsample1d(stride) # TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_size)
        Return:
            Z (np.array): (batch_size, out_channels, output_size)
        """

        # Call Conv1d_stride1
        # TODO
        A = self.conv1d_stride1.forward(A)

        # downsample
        Z = self.downsample1d.forward(A) # TODO

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_size)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_size)
        """
        # Call downsample1d backward
        # TODO
        dLdA = self.downsample1d.backward(dLdZ)

        # Call Conv1d_stride1 backward
        dLdA = self.conv1d_stride1.backward(dLdA) # TODO 

        return dLdA


class Conv2d_stride1():
    def __init__(self, in_channels, out_channels,
                 kernel_size, weight_init_fn=None, bias_init_fn=None):

        # Do not modify this method

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size

        if weight_init_fn is None:
            self.W = np.random.normal(0, 1.0, (out_channels, in_channels, kernel_size, kernel_size))
        else:
            self.W = weight_init_fn(out_channels, in_channels, kernel_size, kernel_size)

        if bias_init_fn is None:
            self.b = np.zeros(out_channels)
        else:
            self.b = bias_init_fn(out_channels)

        self.dLdW = np.zeros(self.W.shape)
        self.dLdb = np.zeros(self.b.shape)

    def conv2d_forward(self, batch,kernel, bias):
            kernel_size = kernel.shape[1]
            width, height = batch.shape[1], batch.shape[2] 
            result = np.zeros((width - kernel_size + 1, height - kernel_size + 1))

            for w_start in range(0,width - kernel_size + 1, 1):
                for h_start in range(0, height - kernel_size + 1, 1):
                    image = batch[:,w_start:w_start + kernel_size, h_start:h_start + kernel_size]
                    conv_image = np.sum(np.multiply(image,kernel))
                    result[w_start, h_start] = conv_image
            
            result += bias
            return result



    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        self.A = A
        

        batch_result = []
        for b_idx in range(len(A)):
            batch = A[b_idx]
            output = None
            for w_idx in range(len(self.W)):
                kernel = self.W[w_idx]
                
                bias = self.b[w_idx]
                conv_result = self.conv2d_forward(batch, kernel, bias)
                
                conv_result = np.expand_dims(conv_result,0)
                if output is None:
                    output = conv_result
                else:
                    output = np.concatenate([output,conv_result], axis = 0)
            batch_result.append(output)

        Z = np.array(batch_result) #TODO
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        batch_result = None
        for b_idx in range(len(dLdZ)):
            A_batch = self.A[b_idx]
            dLdZ_batch = dLdZ[b_idx]
            
            out_c_result = []
            for out_cidx in range(len(dLdZ_batch)):
                out_c_dLdZ = dLdZ_batch[out_cidx]
                out_c_dLdZ = np.expand_dims(out_c_dLdZ, axis = 0)
                in_c_result = []
                for in_cidx in range(len(A_batch)):
                    in_c_A = A_batch[in_cidx]
                    in_c_A = np.expand_dims(in_c_A, axis = 0)
                    
                    in_c = self.conv2d_forward(in_c_A, out_c_dLdZ, 0)
                    in_c_result.append(in_c)
                
                out_c_result.append(np.stack(in_c_result, axis = 0))
            if batch_result is None:
                batch_result = np.stack(out_c_result, axis = 0)
            else:
                batch_result += np.stack(out_c_result, axis = 0)


        self.dLdW = batch_result # TODO        
        self.dLdb = np.sum(dLdZ, axis= (0,2,3)) # TODO

        batch_result = []
        kernel_size = self.W.shape[-1]
        pad_dLdZ = np.pad(dLdZ,((0,0),(0,0),(kernel_size-1,kernel_size-1),(kernel_size-1,kernel_size-1)), constant_values = 0)
        for b_idx in range(len(pad_dLdZ)):
            batch = pad_dLdZ[b_idx]
            output = None
            for w_idx in range(self.W.shape[1]):
                kernel = self.W[:,w_idx,:,:]
                kernel = np.flip(kernel, (1,2))
                conv_result = self.conv2d_forward(batch, kernel, bias = 0)
                conv_result = np.expand_dims(conv_result,0)
                if output is None:
                    output = conv_result
                else:
                    output = np.concatenate([output,conv_result], axis = 0)
            batch_result.append(output)
        dLdA = np.array(batch_result) # TODO

        return dLdA

class Conv2d():
    def __init__(self, in_channels, out_channels, kernel_size, stride,
                weight_init_fn=None, bias_init_fn=None):
        # Do not modify the variable names
        self.stride = stride

        # Initialize Conv2d() and Downsample2d() isntance
        self.conv2d_stride1 = Conv2d_stride1(in_channels, out_channels,kernel_size,
                                             weight_init_fn, bias_init_fn) # TODO


        self.downsample2d = Downsample2d(stride) # TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        # Call Conv2d_stride1
        # TODO
        Z = self.conv2d_stride1.forward(A)

        # downsample
        Z =  self.downsample2d.forward(Z) # TODO

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        # Call downsample1d backward
        # TODO
        dLdA = self.downsample2d.backward(dLdZ)

        # Call Conv1d_stride1 backward
        dLdA = self.conv2d_stride1.backward(dLdA) # TODO 

        return dLdA

class ConvTranspose1d():
    def __init__(self, in_channels, out_channels, kernel_size, upsampling_factor,
                weight_init_fn=None, bias_init_fn=None):
        # Do not modify this method
        self.upsampling_factor = upsampling_factor

        # Initialize Conv1d stride 1 and upsample1d isntance
        #TODO
        self.upsample1d = Upsample1d(upsampling_factor) #TODO
        self.conv1d_stride1 = Conv1d_stride1(in_channels, out_channels, kernel_size,
                                             weight_init_fn=weight_init_fn, bias_init_fn=bias_init_fn) #TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_size)
        Return:
            Z (np.array): (batch_size, out_channels, output_size)
        """
        #TODO
        # upsample
        A_upsampled = self.upsample1d.forward(A) #TODO

        # Call Conv1d_stride1()
        Z = self.conv1d_stride1.forward(A_upsampled) #TODO

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_size)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_size)
        """
        #TODO

        #Call backward in the correct order
        delta_out = self.conv1d_stride1.backward(dLdZ) #TODO

        dLdA = self.upsample1d.backward(delta_out) #TODO

        return dLdA

class ConvTranspose2d():
    def __init__(self, in_channels, out_channels, kernel_size, upsampling_factor,
                weight_init_fn=None, bias_init_fn=None):
        # Do not modify this method
        self.upsampling_factor = upsampling_factor

        # Initialize Conv2d() isntance
        self.conv2d_stride1 = Conv2d_stride1(in_channels, out_channels,kernel_size,
                                             weight_init_fn, bias_init_fn) #TODO
        self.upsample2d = Upsample2d(upsampling_factor) #TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_size)
        Return:
            Z (np.array): (batch_size, out_channels, output_size)
        """
        # upsample
        A_upsampled = self.upsample2d.forward(A) #TODO

        # Call Conv2d_stride1()
        Z = self.conv2d_stride1.forward(A_upsampled) #TODO

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_size)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_size)
        """
        #Call backward in correct order
        delta_out = self.conv2d_stride1.backward(dLdZ) #TODO

        dLdA = self.upsample2d.backward(delta_out) #TODO

        return dLdA

class Flatten():

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, in_width)
        Return:
            Z (np.array): (batch_size, in_channels * in width)
        """
        self.A = A

        Z = A.reshape(A.shape[0],-1) # TODO

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch size, in channels * in width)
        Return:
            dLdA (np.array): (batch size, in channels, in width)
        """
        B,C,W = self.A.shape
        dLdA = dLdZ.reshape(B,C,W) #TODO

        return dLdA

