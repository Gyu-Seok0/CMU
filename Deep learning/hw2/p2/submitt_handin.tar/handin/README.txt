README

1. Files

- main_last.py : main commander file
- Model : Various CNN model including se-resnet, arc face and so on.
- Module: execute file like train, test, and evaluate
- preprocess.py: making the training data and test data.

2. Command
python main_last.py --project [name]
Ex) python main_last.py --project main_test

 

