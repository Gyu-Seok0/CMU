README

1. Files

- main.py : main commander file
- utils: dataset, execute(train/valid), model, normalize

2. Command
python main.py --project [name]
Ex) python main.py --project hw4p2

 

