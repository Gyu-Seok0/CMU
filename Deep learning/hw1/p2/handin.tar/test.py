import torch
import torch.nn as nn 
import torch.optim as optim
import numpy as np
from torchsummaryX import summary
import sklearn
import gc
import zipfile
import pandas as pd
from tqdm.auto import tqdm
import os
import datetime
import wandb
import sklearn.metrics
from torchensemble.utils.logging import set_logger
from torchensemble import VotingClassifier


def test(model, test_loader, device):
    ### What you call for model to perform inference?
    model.eval()
    
    ### List to store predicted phonemes of test data
    test_predictions = []
    ### Which mode do you need to avoid gradients?
    with torch.no_grad():
        for i, frames in enumerate(tqdm(test_loader)):
            frames = frames.float().to(device)             
            output = model(frames)

            ### Get most likely predicted phoneme with argmax
            predicted_phonemes = np.argmax(output.cpu().numpy(), axis = 1)
            ### How do you store predicted_phonemes with test_predictions? Hint, look at eval 
            test_predictions.append(predicted_phonemes)
            
    test_predictions = np.concatenate(test_predictions, axis = 0)
    return test_predictions