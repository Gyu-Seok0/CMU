# command
conda env create --file environment.yaml
conda activate hw1p2_gyuseok
python main.py --project {project_name} --train_path {train_data_path} --val_path {val_data_path} --test_path {test_data_path}

# architectures
Double Cylinder Struture
hidden nodes: [765, 2048, 2048,2048,2048,1024,1024,1024,1024,40] (8 layers)
optimizer: AdamW()
scheduler: CosineAnnealingWarmRestarts(optimizer, T_0 = 5, T_mult = 2, eta_min = 0.0001)


# hyperparameters
learing_rate = 0.01
context = 25
epochs = 30
batch_size = 2048
weight_decay = 1e-4

# best Score
86.7% (Kaggle)

# loading dataset
train,val dataset -> AudioDataset -> Cepstral Normalize -> DataLoader
test dataset -> AudioTestDataset -> Cepstral Normalize -> DataLoader