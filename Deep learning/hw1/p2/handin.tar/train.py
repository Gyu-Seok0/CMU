import torch
import torch.nn as nn 
import torch.optim as optim
import numpy as np
from torchsummaryX import summary
import sklearn
import gc
import zipfile
import pandas as pd
from tqdm.auto import tqdm
import os
import datetime
import wandb
import sklearn.metrics
from torchensemble.utils.logging import set_logger
from torchensemble import VotingClassifier

def train(model, optimizer, criterion, dataloader, device, scheduler, epoch, scaler):

    model.train()
    train_loss = 0.0 #Monitoring Loss
    iters = len(dataloader)
    
    for i, (mfccs, phonemes) in enumerate(tqdm(dataloader)):

        ### Move Data to Device (Ideally GPU)
        mfccs = mfccs.to(device)
        phonemes = phonemes.to(device)
        
        #with torch.cuda.amp.autocast():
        ### Forward Propagation
        logits = model(mfccs)
        ### Loss Calculation
        loss = criterion(logits, phonemes)
        
        # ### Initialize Gradients
        optimizer.zero_grad()

        # ### Backward Propagation
        loss.backward()

        # ### Gradient Descent
        optimizer.step()
        
        train_loss += loss.item()
        
        # scaler.scale(loss).backward()
        # scaler.step(optimizer)
        # scaler.update()

        ###schdueler
        scheduler.step(epoch + i / iters)
        
    train_loss /= len(dataloader)
    return train_loss