import torch
import torch.nn as nn 
import torch.optim as optim
import numpy as np
from torchsummaryX import summary
import sklearn
import gc
import zipfile
import pandas as pd
from tqdm.auto import tqdm
import os
import datetime
import wandb
import sklearn.metrics
from torchensemble.utils.logging import set_logger
from torchensemble import VotingClassifier
# from train import train
# from evaluate import evaluate
# from test import test
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
import argparse
import speechpy

def noramlize_cmvn(train_data, val_data, test_data):
    total_data = np.concatenate([train_data.mfccs, val_data.mfccs, test_data.mfccs], axis = 0)
    total_data = speechpy.processing.cmvn(total_data)
    
    train_idx = train_data.mfccs.shape[0]
    val_idx = train_idx + val_data.mfccs.shape[0]
    
    train_data.mfccs = total_data[:train_idx, :]
    val_data.mfccs = total_data[train_idx:val_idx, :]
    test_data.mfccs = total_data[val_idx:, :]
    return train_data, val_data, test_data


class AudioDataset(torch.utils.data.Dataset):

    def __init__(self, data_path, context, offset=0, partition= "train", limit=-1): # Feel free to add more arguments

        self.context = context
        self.offset = offset
        self.data_path = data_path

        self.mfcc_dir = os.path.join(data_path, "mfcc") # TODO: MFCC directory - use partition to acces train/dev directories from kaggle data
        self.transcript_dir = os.path.join(data_path, "transcript") # TODO: Transcripts directory - use partition to acces train/dev directories from kaggle data

        mfcc_names = os.listdir(self.mfcc_dir) # TODO: List files in X_dir using os.listdir in sorted order, optionally subset using limit to slice the number of files you load
        mfcc_names = sorted(mfcc_names)
        
        transcript_names = os.listdir(self.transcript_dir) # TODO: List files in Y_dir using os.listdir in sorted order, optionally subset using limit to slice the number of files you load
        transcript_names = sorted(transcript_names)

        assert len(mfcc_names) == len(transcript_names) # Making sure that we have the same no. of mfcc and transcripts

        self.mfccs, self.transcripts = [], []

        # TODO:
        # Iterate through mfccs and transcripts
        for i in range(0, len(mfcc_names)):
        #   Load a single mfcc
            mfcc = np.load(os.path.join(self.mfcc_dir, mfcc_names[i]))
        #   Optionally do Cepstral Normalization of mfcc
        #   Load the corresponding transcript
            transcript = np.load(os.path.join(self.transcript_dir, transcript_names[i]))[1:-1] # Remove [SOS] and [EOS] from the transcript (Is there an efficient way to do this 
            # without traversing through the transcript?)
        #   Append each mfcc to self.mfcc, transcript to self.transcript
            self.mfccs.append(mfcc)
            self.transcripts.append(transcript)

        

        # NOTE:
        # Each mfcc is of shape T1 x 15, T2 x 15, ...
        # Each transcript is of shape (T1+2) x 15, (T2+2) x 15 before removing [SOS] and [EOS]

        # TODO: Concatenate all mfccs in self.X such that the final shape is T x 15 (Where T = T1 + T2 + ...) 
        self.mfccs = np.concatenate(self.mfccs, axis = 0)

        # TODO: Concatenate all transcripts in self.Y such that the final shape is (T,) meaning, each time step has one phoneme output
        self.transcripts = np.concatenate(self.transcripts, axis = 0)
        # Hint: Use numpy to concatenate

        # Take some time to think about what we have done. self.mfcc is an array of the format (Frames x Features). Our goal is to recognize phonemes of each frame
        # From hw0, you will be knowing what context is. We can introduce context by padding zeros on top and bottom of self.mfcc
        self.mfccs = np.pad(self.mfccs, ((self.context, self.context), (0, 0)), 'constant', constant_values=0) # TODO ??

        # These are the available phonemes in the transcript
        self.phonemes = [
            'SIL',   'AA',    'AE',    'AH',    'AO',    'AW',    'AY',  
            'B',     'CH',    'D',     'DH',    'EH',    'ER',    'EY',
            'F',     'G',     'HH',    'IH',    'IY',    'JH',    'K',
            'L',     'M',     'N',     'NG',    'OW',    'OY',    'P',
            'R',     'S',     'SH',    'T',     'TH',    'UH',    'UW',
            'V',     'W',     'Y',     'Z',     'ZH',    '<sos>', '<eos>']
        # But the neural network cannot predict strings as such. Instead we map these phonemes to integers

        self.transcripts = list(map(lambda x: self.phonemes.index(x), self.transcripts)) # TODO: Map the phonemes to their corresponding list indexes in self.phonemes
        # Now, if an element in self.transcript is 0, it means that it is 'SIL' (as per the above example)

        # Length of the dataset is now the length of concatenated mfccs/transcripts
        self.length = len(self.mfccs) - 2*self.context

    def __len__(self):
        return self.length

    def __getitem__(self, ind):
        
        #frames = np.pad(np.expand_dims(self.mfccs[ind], axis = 0), ((0, 0), (self.context, self.context)), 'constant', constant_values = 0) # TODO: Based on context and offset, return a frame at given index with context frames to the left, and right.
        frames = self.mfccs[ind : ind + 2*self.context + 1]
        # After slicing, you get an array of shape (2*context+1) x 15. But our MLP needs 1d data and not 2d.
        frames = frames.flatten() # TODO: Flatten to get 1d data

        frames = torch.FloatTensor(frames) # Convert to tensors
        phoneme = torch.tensor(self.transcripts[ind])       

        return frames, phoneme

class AudioTestDataset(torch.utils.data.Dataset):
    def __init__(self, data_path, context, offset=0, partition= "test", limit=-1): # Feel free to add more arguments

        self.context = context
        self.offset = offset
        self.data_path = data_path

        self.mfcc_dir = os.path.join(data_path, "mfcc") # TODO: MFCC directory - use partition to acces train/dev directories from kaggle data
        mfcc_names = os.listdir(self.mfcc_dir) # TODO: List files in X_dir using os.listdir in sorted order, optionally subset using limit to slice the number of files you load
        mfcc_names = sorted(mfcc_names)
        self.mfccs = []

        for i in range(0, len(mfcc_names)):
        #   Load a single mfcc
            mfcc = np.load(os.path.join(self.mfcc_dir, mfcc_names[i]))
            self.mfccs.append(mfcc)

        # NOTE:
        # Each mfcc is of shape T1 x 15, T2 x 15, ...
        # Each transcript is of shape (T1+2) x 15, (T2+2) x 15 before removing [SOS] and [EOS]

        # TODO: Concatenate all mfccs in self.X such that the final shape is T x 15 (Where T = T1 + T2 + ...) 
        self.mfccs = np.concatenate(self.mfccs, axis = 0)

        # From hw0, you will be knowing what context is. We can introduce context by padding zeros on top and bottom of self.mfcc
        self.mfccs = np.pad(self.mfccs, ((self.context, self.context), (0, 0)), 'constant', constant_values=0) # TODO ??


        # Length of the dataset is now the length of concatenated mfccs/transcripts
        self.length = len(self.mfccs) - 2*self.context
        
    
    def __len__(self):
        return self.length
        
        
    def __getitem__(self, ind):
        frames = self.mfccs[ind : ind + 2*self.context + 1]
        # After slicing, you get an array of shape 2*context+1 x 15. But our MLP needs 1d data and not 2d.
        frames = frames.flatten() # TODO: Flatten to get 1d data
        frames = torch.FloatTensor(frames) # Convert to tensors
        
        return frames
        
    
    # TODO: Create a test dataset class similar to the previous class but you dont have transcripts for this
    # Imp: Read the mfccs in sorted order, do NOT shuffle the data here or in your dataloader.
