import torch
import torch.nn as nn 
import torch.optim as optim
import numpy as np
from torchsummaryX import summary
import sklearn
import gc
import zipfile
import pandas as pd
from tqdm.auto import tqdm
import os
import datetime
import wandb
import sklearn.metrics
from torchensemble.utils.logging import set_logger
from torchensemble import VotingClassifier
# from train import train
# from evaluate import evaluate
# from test import test
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
import argparse

class Network(torch.nn.Module):
    def __init__(self, context):
        super(Network, self).__init__()
        input_size = (2*context + 1) * 15
        output_size = 40
        layers = []
        dims = [input_size] + [2048]*4 + [1024]*4
        in_out_dims = list(zip(dims[:-1], dims[1:]))
        for i in range(len(in_out_dims)):
           in_dim, out_dim = in_out_dims[i]
           layers += self.make_layer(in_dim,out_dim)

        # classfier 
        layers += [nn.Linear(out_dim, output_size)]
        self.layers = nn.Sequential(*layers)
        self.initalize_weights()
        
    def make_layer(self, in_dim, out_dim):
        return [nn.Linear(in_dim, out_dim),
                nn.BatchNorm1d(out_dim),
                nn.GELU(),
                nn.Dropout(np.random.uniform(0.1,0.5))]
        
    def forward(self,x):
        return self.layers(x)
    
    def initalize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.kaiming_uniform_(m.weight.data)
                nn.init.constant_(m.bias,0)
            elif isinstance(m, nn.BatchNorm1d):
                nn.init.constant_(m.weight,1)
                nn.init.constant_(m.bias,0)
        print("[Done] Weight Initalization")