import torch
import torch.nn as nn 
import torch.optim as optim
import numpy as np
from torchsummaryX import summary
import sklearn
import gc
import zipfile
import pandas as pd
from tqdm.auto import tqdm
import os
import datetime
import wandb
import sklearn.metrics
#from torchensemble.utils.logging import set_logger
#from torchensemble import VotingClassifier
from train import train
from evaluate import evaluate
from test import test
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
import argparse
from Module.dataset import *
from Module.model import *


def main(args):
    print(args)
    
    device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    print("Device: ", device)

    # Dataset class to load train and validation data
    ### PHONEME LIST
    PHONEMES = [
                'SIL',   'AA',    'AE',    'AH',    'AO',    'AW',    'AY',  
                'B',     'CH',    'D',     'DH',    'EH',    'ER',    'EY',
                'F',     'G',     'HH',    'IH',    'IY',    'JH',    'K',
                'L',     'M',     'N',     'NG',    'OW',    'OY',    'P',
                'R',     'S',     'SH',    'T',     'TH',    'UH',    'UW',
                'V',     'W',     'Y',     'Z',     'ZH',    '<sos>', '<eos>']

    config = {
        'epochs': args.epoch,
        'batch_size' : args.batch_size,
        'context' : args.context,
        'learning_rate' : args.lr,
        'architecture' : 'very-low-cutoff',
    }

    train_data = AudioDataset(data_path = args.train_path,
                              context = config["context"] ) #TODO: Create a dataset object using the AudioDataset class for the training data 

    val_data = AudioDataset(data_path = args.val_path,
                            context = config["context"],
                            partition = "val",
                            ) # TODO: Create a dataset object using the AudioDataset class for the validation data 

    test_data = AudioTestDataset(data_path = args.test_path,
                                 context = config["context"],
                                ) # TODO: Create a dataset object using the AudioTestDataset class for the test data 

    train_data, val_data, test_data = noramlize_cmvn(train_data, val_data, test_data)
    print("[Done] Cepstral Normalize")

    # Define dataloaders for train, val and test datasets
    # Dataloaders will yield a batch of frames and phonemes of given batch_size at every iteration
    train_loader = torch.utils.data.DataLoader(train_data, num_workers= 40,
                                            batch_size=config['batch_size'], pin_memory= True,
                                            shuffle= True)

    val_loader = torch.utils.data.DataLoader(val_data, num_workers= 40,
                                            batch_size=config['batch_size'], pin_memory= True,
                                            shuffle= False)

    test_loader = torch.utils.data.DataLoader(test_data, num_workers= 40, 
                                            batch_size=config['batch_size'], pin_memory= True, 
                                            shuffle= False)

    # print the statics for the dataset
    print("Batch size: ", config['batch_size'])
    print("Context: ", config['context'])
    print("Input size: ", (2*config['context']+1)*15)
    print("Output symbols: ", len(PHONEMES))
    print("Train dataset samples = {}, batches = {}".format(train_data.__len__(), len(train_loader)))
    print("Validation dataset samples = {}, batches = {}".format(val_data.__len__(), len(val_loader)))
    print("Test dataset samples = {}, batches = {}".format(test_data.__len__(), len(test_loader)))


    # model,criterion,optimizer  
    model = Network(context = config['context'])
    model = model.to(device)
    
    # Multi-GPU
    if args.gpu_ids is not None:
        model = torch.nn.DataParallel(model, device_ids = args.gpu_ids)

    if args.pretrain is not None:
        dic = torch.load(args.pretrain)
        model.load_state_dict(dic["model_state_dict"])
        print("[Success] Loading the pretrained model")
    else:
        print("[Fail] Not Loading the pretrained model")


    # Define for loss, optimizer, and scheduler    
    criterion = torch.nn.CrossEntropyLoss() 
    optimizer = torch.optim.AdamW(model.parameters(), 
                                  lr = config["learning_rate"],
                                  weight_decay = args.weight_decay)
    scheduler = CosineAnnealingWarmRestarts(optimizer, T_0 = 5, T_mult = 2, eta_min = 0.0001)


    '''
    wandb
    '''
    if args.wandab:
        wandb.login(key="e0408f5d7b96be3d00be30b39eda0f1e259672ed") #API Key is in your wandb account, under settings (wandb.ai/settings)
        # Create your wandb run
        run = wandb.init(
            name = args.project, ### Wandb creates random run names if you skip this field, we recommend you give useful names
            reinit=True, ### Allows reinitalizing runs when you re-run this cell
            project="hw1p2", ### Project should be created in your wandb account 
            config=config ### Wandb Config for your run
        ) 
        ### Save your model architecture as a string with str(model) 
        model_arch = str(model)

        ### Save it in a txt file 
        arch_file = open("model_arch.txt", "w")
        file_write = arch_file.write(model_arch)
        arch_file.close()

        ### log it in your wandb run with wandb.save()
        wandb.save('model_arch.txt')


    # Iterate over number of epochs to train and evaluate your model
    torch.cuda.empty_cache()
    best_acc = 0.0 ### Monitor best accuracy in your run

    output = None
    scaler = torch.cuda.amp.GradScaler()
    for epoch in range(config['epochs']):

        print("\nEpoch {}/{}".format(epoch+1, config['epochs']))

        train_loss = train(model, optimizer, criterion, train_loader, device, scheduler, epoch, scaler)
        accuracy = evaluate(model, val_loader, device)

        print("\tTrain Loss: {:.4f}".format(train_loss))
        print("\tValidation Accuracy: {:.2f}%".format(accuracy))


        ### Log metrics at each epoch in your run - Optionally, you can log at each batch inside train/eval functions (explore wandb documentation/wandb recitation)
        if args.wandab:
            wandb.log({"train loss": train_loss, "validation accuracy": accuracy})

        ### Save checkpoint if accuracy is better than your current best
        if accuracy >= best_acc:
            best_acc = accuracy
            ### Save checkpoint with information you want
            file_name = f'./{args.project}.pth'
            torch.save({'epoch': epoch,
                        'model_state_dict': model.state_dict(),
                        'optimizer_state_dict': optimizer.state_dict(),
                        'loss': train_loss,
                        'acc': accuracy}, file_name)
            
            #output = test(model, test_loader, device)    
            ### Save checkpoint in wandb
            if args.wandab:
                wandb.save(file_name)

        if (epoch+1) % 10 == 0 and accuracy == best_acc:
            output = test(model, test_loader, device)
            df = pd.DataFrame([np.arange(len(output)),output]).T
            df.columns = ["id","label"]
            df.to_csv(f"{args.project}.csv", index = False)
            ### Submit to kaggle competition using kaggle API
    
    # ### Finish your wandb run
    if args.wandab:
        run.finish()

    # submit
    if args.submit:
        os.system(f"kaggle competitions submit -c 11-785-f22-hw1p2 -f ./{args.project}.csv -m \"Test Submission\"")

    print(args)
    print("[Done] Experiment")



if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    # hyper parameter
    parser.add_argument("--lr", type = float, default = 0.01, help = "learning_rate")
    parser.add_argument("--context", type = int, default = 25, help = "context size")
    parser.add_argument("--epoch", type = int, default = 30, help = "epoch")
    parser.add_argument("--batch_size", type= int, default = 2048, help = "the size of batch")
    parser.add_argument("--weight_decay", type = float, default = 1e-4, help = "L2 Regularizer value")
    
    # dataset
    parser.add_argument("--train_path", type = str, default = "/home/gyuseok/content/data/train-clean-100")
    parser.add_argument("--val_path", type = str, default = "/home/gyuseok/content/data/dev-clean")
    parser.add_argument("--test_path", type = str, default = "/home/gyuseok/content/data/test-clean")

    # others
    parser.add_argument("--pretrain", type = str, default = None, help = "path for pretrain model's pth (e.g., ./lr0.1.pth) ")
    parser.add_argument("--project", type = str, default = "Recommend", help = "name of project")
    parser.add_argument("--wandab", type = bool, default = False, help = "Whether using wandb or not")
    parser.add_argument("--submit", type = bool, default = False, help = "Whether submitting via Kaggle command or not")
    parser.add_argument("--gpu_ids", type = list, default = None, help = "your gpu ids for Mulit-process like [0,1] ")
 
    args = parser.parse_args()
    main(args)